package org.techtown.savehome;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class NumberActivity extends AppCompatActivity {

    private Intent mlntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number);

    }


    public void phoneClicked(View v){
        Intent mIntent = new Intent(Intent.ACTION_PICK);
        mIntent.setData(ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(mIntent, 0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        String sNumber = null;
        if (resultCode == RESULT_OK) {
            Cursor cursor = getContentResolver().query(data.getData(),
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
            cursor.moveToFirst();
            String sName = cursor.getString(0);
            sNumber = cursor.getString(1);
            cursor.close();
        }


        super.onActivityResult(requestCode, resultCode, data);
        Intent intent1 = new Intent(NumberActivity.this, BlueActivity.class);
        Intent intent2 = new Intent(NumberActivity.this, Alram1.class);
        intent1.putExtra("value1", sNumber);
        intent2.putExtra("value1", sNumber);
        getApplicationContext().startActivity(intent1);
        getApplicationContext().startActivity(intent2);
    }

}